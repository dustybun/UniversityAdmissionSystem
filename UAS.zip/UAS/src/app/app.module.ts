﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import{FormsModule} from '@angular/forms';
import {GetSchedulesComponent} from './_components/app.getschedulescomponent';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {GetProgramsComponent} from './_components/app.getprogramscomponent';
import { AddApplicantComponent } from './_components/app.addapplicant';
import { Routes, RouterModule } from '@angular/router'
import {UserHomeComponent} from './_components/app.userhome';
import {ViewApplicant} from './_components/app.viewapplicant'
import { AdminHomeComponent } from './_components/app.adminhome';
import { ApproveApplicantComponent } from './_components/app.approveapplicant';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { AddScheduleComponent } from './_components/app.addschedule';
import { AddProgramComponent } from './_components/app.addprogram';
import { DeleteScheduleComponent } from './_components/app.deleteschedule';
import {ConfirmationPopoverModule} from 'angular-confirmation-popover';
import { DeleteProgramComponent } from './_components/app.deleteprogram';
import { Error404Component } from './_components/app.error404';
import { Error403Component } from './_components/app.error403';
//import { RegistrationComponent } from './_components/app.registration';
import { LoginComponent } from './_components/app.login';
import { HomeComponent } from './_components/app.home';
import { LogoutComponent } from './_components/app.logout';
import { AboutComponent } from './_components/app.about';
import { BasicAuthHtppInterceptorService } from './_service/app.basicauthservice';


const myRoute: Routes = [
    { path: '', redirectTo:'home', pathMatch:'full'},
    { path: 'adminhome', component: AdminHomeComponent},
    { path: 'userhome', component: UserHomeComponent},
    { path: 'home', component: HomeComponent},
    { path: 'addapplicant', component:AddApplicantComponent},
    { path: 'viewapplicant', component: ViewApplicant},
    { path: 'approveapplicant', component:ApproveApplicantComponent},
    { path: 'addschedule', component: AddScheduleComponent },
    { path: 'addprogram', component :AddProgramComponent},
    { path: 'deleteschedule', component: DeleteScheduleComponent},
    { path: 'deleteprogram', component:DeleteProgramComponent},
    { path: 'forbidden', component:Error403Component}, 
    //{ path: 'register', component:RegistrationComponent},
    { path: 'login' ,component:LoginComponent},
    { path: 'logout', component:LogoutComponent},
    { path: 'about', component:AboutComponent},
    { path: '**', component:Error404Component}
    
  
]

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        BrowserAnimationsModule,
        RouterModule.forRoot(myRoute),
        NgxPaginationModule,
        ConfirmationPopoverModule.forRoot({confirmButtonType:'danger'})
        
    ],
    declarations: [
        AppComponent, GetSchedulesComponent,GetProgramsComponent, 
        AddApplicantComponent, ViewApplicant,
        ApproveApplicantComponent,
        AdminHomeComponent, UserHomeComponent, HomeComponent,
        AddScheduleComponent, AddProgramComponent,DeleteScheduleComponent,DeleteProgramComponent,
        Error404Component, Error403Component,
        //RegistrationComponent,
        LoginComponent,LogoutComponent, AboutComponent
   	],
    providers: [ {  
        provide:HTTP_INTERCEPTORS, useClass:BasicAuthHtppInterceptorService, multi:true 
      }],
    bootstrap: [AppComponent]
})

export class AppModule { }