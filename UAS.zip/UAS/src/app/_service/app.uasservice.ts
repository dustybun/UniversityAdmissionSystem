import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { ScheduleModel } from '../_model/app.schedulemodel';
import { ApplicantModel } from '../_model/app.applicantmodel';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserModel } from '../_model/app.usermodel';

export class User{
    constructor(
      public status:string,
       ) {}   
  }

  export class JwtResponse{
    constructor(
      public jwttoken:string,
       ) {}
    
  }

@Injectable({
    providedIn: 'root'
})
export class UasService {

    userObject:any;

    constructor(private myhttp: HttpClient) { }

    getSchedules() {
       // let headers = new HttpHeaders();
       // headers = headers.set('Authorization', sessionStorage.getItem('token'));
      //  return this.myhttp.get("http://"+ window.location.hostname+":9123/getSchedules",  { headers: headers });
        return this.myhttp.get("http://"+ window.location.hostname+":9123/getSchedule");
    }

    getPrograms(scheduleId: any) {
        let params = new HttpParams();
        params = params.append('scheduleId', scheduleId);
        return this.myhttp.get('http://'+ window.location.hostname+':9123/getPrograms', { params: params });
    }

    addApplicant(applicant: any) {

        return this.myhttp.post('http://'+ window.location.hostname+':9123/addApplicant', applicant);
    }

    getUserApplicants(applicantId: any) {
    //     let params = new HttpParams();
    //     params = params.append('userId', applicantId);
    //     return this.myhttp.get('http://'+ window.location.hostname+':9123/viewApplicants', { params: params });
            return this.myhttp.get('http://'+ window.location.hostname+':9123/viewApplicants');

            
    }

    getApplicants(scheduleId: any) {
        let params = new HttpParams();
        params = params.append('scheduleId', scheduleId);
        return this.myhttp.get('http://'+ window.location.hostname+':9123/pendingApplicants', { params: params });
    }

    approveApplicant(applicantId: any) {
        let params = new HttpParams();
        params = params.append('applicantId', applicantId);
        return this.myhttp.post("http://"+ window.location.hostname+":9123/approveApplicant?applicantId" + applicantId, params);
    }

    addSchedule(data: any) {
        return this.myhttp.post("http://"+ window.location.hostname+":9123/addSchedule",data);
    }

    addProgram(scheduleId:any,data:any)
    {
        let params = new HttpParams();
        params = params.append('scheduleId', scheduleId);
        params = params.append('programName', data.programName);
        return this.myhttp.post("http://"+ window.location.hostname+":9123/addProgram",params);
    }

    deleteSchedule(scheduleId: any) {
        // let params: URLSearchParams = new URLSearchParams();
        // params.set('appid', StaticSettings.API_KEY);
        return this.myhttp.delete("http://"+ window.location.hostname+":9123/removeSchedule?scheduleId="+scheduleId,{responseType: 'text'});
     }

     deleteProgram(scheduleId:any,programId:any)
    {
        return this.myhttp.delete("http://"+ window.location.hostname+":9123/removeProgram?scheduleId="+scheduleId+"&programId="+programId,{responseType: 'text'});
    }

    download(userId:any): Observable<Blob>{
        return this.myhttp.get("http://"+ window.location.hostname+":9123/download?userId="+userId, {'responseType':"blob"});
    }

    getUser(useremail:any){
        return this.myhttp.get("http://"+ window.location.hostname+":9123/finduser?userEmail="+useremail);
    }


    /*
    Description: Service method to call /authenticate. Checks login details and returns a token is successful.
    */
    authenticate(username:string, password:string) {
        console.log("Inside service authenticate.. email: "+username+" password: "+password);
        const reqbody={userEmail: username, password:password};
        console.log(JSON.stringify(reqbody))
        
        return this.myhttp.post<any>('http://'+ window.location.hostname+':9123/authenticate', {userEmail: username, password:password});
      }

    isUserLoggedIn() {
        let user = sessionStorage.getItem('username')
        console.log(!(user === null))
        return !(user === null)
    }

    logOut() {
        sessionStorage.removeItem('username');
        sessionStorage.removeItem('token');
        sessionStorage.removeItem('userId');
        sessionStorage.removeItem('userRole');
        sessionStorage.removeItem('userName');
    }

    register(newUser: any){
        return this.myhttp.post('http://'+ window.location.hostname+':9123/register', newUser);
   }

//    reject(applicantId:any){
//     return this.myhttp.delete('http://localhost:9123/rejectapplicant?applicantId='+applicantId);
// }

reject(applicantId: any) {
    let params = new HttpParams();
    params = params.append('applicantId', applicantId);
    return this.myhttp.post("http://"+ window.location.hostname+":9123/rejectapplicant?applicantId" + applicantId, params,{responseType: 'text'});
}

    
}