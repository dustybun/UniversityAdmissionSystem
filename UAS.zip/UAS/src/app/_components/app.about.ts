import {Component, OnInit} from '@angular/core';


@Component({
    selector: 'about',
    templateUrl:'../_html/app.about.html'
})
export class AboutComponent {



}

    