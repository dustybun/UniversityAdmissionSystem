import {UasService} from '../_service/app.uasservice';
import {Router} from "@angular/router"
import { Component, OnInit } from "@angular/core";

@Component({
    selector:'addschedule',
    templateUrl:'../_html/app.addschedule.html'
})
export class AddScheduleComponent implements OnInit
{
    ngOnInit(){
        // if(!(sessionStorage.getItem('userRole') === "ROLE_Admin")){
        //     this.router.navigate(['forbidden']);
        // }
    }

    model:any={};
    msg: boolean = false;
    errorMessage:any;
    constructor(private service:UasService,private router:Router)
    {
        
    }
   
    addSchedule():any
    {
        this.service.addSchedule(this.model).subscribe((data:any)=>{alert("Schedule added successfully");
        location.reload();
    },error => this.errorMessage= error.error
        
    );
    }
}
