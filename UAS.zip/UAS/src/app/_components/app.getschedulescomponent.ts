import {Component, OnInit} from '@angular/core';
import { ScheduleModel } from '../_model/app.schedulemodel';
import {UasService} from '../_service/app.uasservice';
@Component({
    selector: 'getschedules',
    templateUrl: '../_html/app.getschedules.html'
})
export class GetSchedulesComponent implements OnInit{
    
    scheduleList:ScheduleModel[]=[];

    constructor(private service:UasService){
        
    }
    
    ngOnInit(){
        this.service.getSchedules().subscribe((scheduleList:ScheduleModel[]) => this.scheduleList = scheduleList);
    }

}