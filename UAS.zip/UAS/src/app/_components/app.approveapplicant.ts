import {Component, OnInit} from '@angular/core';
import { UasService } from '../_service/app.uasservice';
import { ScheduleModel } from '../_model/app.schedulemodel';
import { ApplicantModel } from '../_model/app.applicantmodel';
import { Router } from '@angular/router';

@Component({
    selector: 'approveapplicant',
    templateUrl:'../_html/app.approveapplicant.html'
})

export class ApproveApplicantComponent implements OnInit{
    scheduleList:ScheduleModel[]=[];
    scheduleId:any;
    applicantList:ApplicantModel[]=null;
    applicantId:any;
    buttonStatus:string='0';
    orderMonth:any;
    searchSchedule:any='';
    orderUser:any;
    searchUser:any='';

    constructor(private service:UasService, private router:Router){    
    }

    ngOnInit()  {
        // if(!(sessionStorage.getItem('userRole') === "ROLE_Admin")){
        //     this.router.navigate(['forbidden']);
        // }
        this.scheduleId=null;
        this.applicantList=null;
        this.applicantId=null;
        this.service.getSchedules().subscribe((scheduleList:ScheduleModel[]) => this.scheduleList = scheduleList);
    }

    selectSchedule(schedule:ScheduleModel){
        if(this.scheduleId == null)
        {
            this.scheduleId=schedule.scheduleId;
            this.scheduleList=[];
            this.scheduleList.push(schedule);
            this.service.getApplicants(schedule.scheduleId).subscribe((applicantList:ApplicantModel[]) => this.applicantList = applicantList);
        }   
    }

    changeSchedule(){
        this.ngOnInit();
    }

    approve(applicant:ApplicantModel){
        this.applicantId=applicant.applicantId;
        this.applicantList = [];
        this.applicantList.push(applicant);
        this.buttonStatus='1';
    }

    confirmApprove(){
        this.service.approveApplicant(this.applicantId).subscribe(
         (data:boolean) => {alert("Approved Successfully.");
         this.service.getApplicants(this.scheduleId).subscribe((applicantList:ApplicantModel[]) => this.applicantList = applicantList);
        }
     //    ,error => alert(error.error)
         ,error => alert("Please refresh the page.")
        );
        this.applicantId=null;
        this.buttonStatus='0';
        this.applicantList = [];
        this.service.getApplicants(this.scheduleId).subscribe((applicantList:ApplicantModel[]) => this.applicantList = applicantList);
    }

    reject(applicant:ApplicantModel){
        this.applicantId=applicant.applicantId;
        this.applicantList = [];
        this.applicantList.push(applicant);
        this.buttonStatus='2';
    }

    confirmReject(){
        this.service.reject(this.applicantId).subscribe(
         (data:any) => {
         alert("Rejected successfully.");
         this.service.getApplicants(this.scheduleId).subscribe((applicantList:ApplicantModel[]) => this.applicantList = applicantList);
        }
     //    ,error => alert(error.error)
         ,error => alert("Please refresh the page.")
        );
        this.applicantId=null;
        this.buttonStatus='0';
        this.applicantList = [];
        this.service.getApplicants(this.scheduleId).subscribe((applicantList:ApplicantModel[]) => this.applicantList = applicantList);
    }

    sortName() {
        if (this.orderMonth != 1) {
          this.scheduleList.sort((left, right) => left.scheduleMonth.localeCompare(right.scheduleMonth));
          this.orderMonth = 1;
        }
        else if (this.orderMonth == 1){
          this.scheduleList.sort((right, left) => left.scheduleMonth.localeCompare(right.scheduleMonth));
          this.orderMonth = 0;
        }
      }

      searchScheduleFx(){
    
        if(!this.searchSchedule){
            this.scheduleId=null;
            this.applicantList=null;
            this.applicantId=null;
            this.service.getSchedules().subscribe((scheduleList:ScheduleModel[]) => this.scheduleList = scheduleList);
       
        }
        else{
          
        for(let i=this.scheduleList.length-1;i>=0 ;i--){
          if(this.searchSchedule != this.scheduleList[i].scheduleMonth){
            this.scheduleList.splice(i,1);
          }
        }
      }
    }

}