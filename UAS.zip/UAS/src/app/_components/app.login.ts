import { Component, OnInit } from "@angular/core";
import { UasService } from "../_service/app.uasservice";
import { Router } from '@angular/router';
import { UserModel } from "../_model/app.usermodel";

@Component({
  selector: 'login',
  templateUrl: '../_html/app.login.html'
})

export class LoginComponent implements OnInit {
  model: any = [];
  useremail: any;
  password: any;
  invalidLogin = false;
  message:string;

  constructor(private router: Router,
    private uasservice: UasService) { }

  ngOnInit() {
  }

  checkLogin() {
    console.log("Inside login.ts checkLogin.. email: " + this.useremail + " password: " + this.password)
    this.uasservice.authenticate(this.useremail, this.password).subscribe(
      userData => {
        sessionStorage.setItem('username', this.useremail);
        let tokenStr = 'Bearer ' + userData.token;
        sessionStorage.setItem('token', tokenStr);
        this.uasservice.getUser(this.useremail).subscribe((data: UserModel) => {
          this.model = data;
          sessionStorage.setItem('userRole', data.userRole);
          sessionStorage.setItem('userId', data.userId);
          sessionStorage.setItem('userName', data.userName)
          this.checkRoles();
        });
      },
      error => {
        alert("Invalid Credentials  ")
      });
    }


  checkRoles(){

    if (sessionStorage.getItem('userRole') === "ROLE_MAC") {
      this.router.navigate(['/machome']).then(()=>{window.location.reload();});
    } 
    else if(sessionStorage.getItem('userRole') === "ROLE_Admin"){
      this.router.navigate(['/adminhome']).then(()=>{window.location.reload();});
    }
    
  }
}