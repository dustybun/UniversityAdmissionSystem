import { Component, OnInit } from "@angular/core";
import { UasService } from '../_service/app.uasservice';
import { ScheduleModel } from "../_model/app.schedulemodel";
import { Router } from "@angular/router";
@Component({
    selector: 'deleteschedule',
    templateUrl: '../_html/app.deleteschedule.html'

})
export class DeleteScheduleComponent implements OnInit {

    scheduleList: ScheduleModel[] = [];
    public popoverTitle: string = 'Delete Confirmation';
    public popoverMessage: string = "Do you really want to delete the schedule";
    public confirmClicked: boolean = false;
    public cancelClicked: boolean = false;
    orderMonth:any;
    searchSchedule:any='';

    constructor(private service: UasService, private router: Router) {
    }
    ngOnInit() {
        // if (!(sessionStorage.getItem('userRole') === "ROLE_Admin")) {
        //     this.router.navigate(['forbidden']);
        // }
        this.service.getSchedules().subscribe((data: ScheduleModel[]) => this.scheduleList = data);

    }
    deleteSchedule(scheduleId: any): any {
        this.service.deleteSchedule(scheduleId).subscribe(
            (data: string) => {
                alert(data)
                this.service.getSchedules().subscribe((data: ScheduleModel[]) => this.scheduleList = data);
            },
            error => alert(error.message)

        );
    }

    sortName() {
        if (this.orderMonth != 1) {
          this.scheduleList.sort((left, right) => left.scheduleMonth.localeCompare(right.scheduleMonth));
          this.orderMonth = 1;
        }
        else if (this.orderMonth == 1){
          this.scheduleList.sort((right, left) => left.scheduleMonth.localeCompare(right.scheduleMonth));
          this.orderMonth = 0;
        }
      }

      searchScheduleFx(){
    
        if(!this.searchSchedule){
            this.service.getSchedules().subscribe((data: ScheduleModel[]) => this.scheduleList = data);

        }
        else{
          
        for(let i=this.scheduleList.length-1;i>=0 ;i--){
          if(this.searchSchedule != this.scheduleList[i].scheduleMonth){
            this.scheduleList.splice(i,1);
          }
        }
      }
    }

}
