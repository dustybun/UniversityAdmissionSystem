import {Component, OnInit} from '@angular/core';
import {ProgramModel} from '../_model/app.programmodel';
import {UasService} from '../_service/app.uasservice';
@Component({
    selector: 'getprograms',
    templateUrl: '../_html/app.getprograms.html'
})
export class GetProgramsComponent implements OnInit{
    
    programList:ProgramModel[]=[];

    constructor(private service:UasService){    
    }
    
    ngOnInit(){
     //   this.service.getPrograms().subscribe((programList:ProgramModel[]) => this.programList = programList);
    }

}