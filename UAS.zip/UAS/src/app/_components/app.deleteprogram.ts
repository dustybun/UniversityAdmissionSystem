import {Component, OnInit} from '@angular/core';
import { UasService } from '../_service/app.uasservice';
import { ScheduleModel } from '../_model/app.schedulemodel';
import { ProgramModel } from '../_model/app.programmodel';
import { Router } from '@angular/router';

@Component({
    selector: 'deleteprogram',
    templateUrl:'../_html/app.deleteprogram.html'
})

export class DeleteProgramComponent implements OnInit{
    scheduleList:ScheduleModel[]=[];
    scheduleId:any;
    programList:ProgramModel[]=null;
    programId:any;
    orderMonth:any;
    searchSchedule:any='';
    orderProgramName:any;
    searchProgram:any='';

    constructor(private service:UasService, private router:Router){    
    }

    ngOnInit()  {
        // if(!(sessionStorage.getItem('userRole') === "ROLE_Admin")){
        //     this.router.navigate(['forbidden']);
        // }
        this.scheduleId=null;
        this.programList=null;
        this.programId=null;
        this.service.getSchedules().subscribe((scheduleList:ScheduleModel[]) => this.scheduleList = scheduleList);
    }

    selectSchedule(schedule:ScheduleModel){
        if(this.scheduleId == null)
        {
            this.scheduleId=schedule.scheduleId;
            this.scheduleList=[];
            this.scheduleList.push(schedule);
            this.service.getPrograms(schedule.scheduleId).subscribe((programList:ProgramModel[]) => this.programList = programList);
        }   
    }

    changeSchedule(){
        this.ngOnInit();
    }

    delete(program:ProgramModel){
        this.programId=program.programId;
        this.programList = [];
        this.programList.push(program);
    }

    confirmDelete(){
        this.service.deleteProgram(this.scheduleId,this.programId).subscribe(
        (data:string)=>{alert(data);
        this.service.getPrograms(this.scheduleId).subscribe((programList:ProgramModel[]) => this.programList = programList);
        this.programId=null;
        }
        ,error => alert("Please refresh the page.")
         
        );
        // this.programId=null;
        // this.programList = [];
        // this.service.getPrograms(this.scheduleId).subscribe((programList:ProgramModel[]) => this.programList = programList);
        
    }

    sortName() {
        if (this.orderMonth != 1) {
          this.scheduleList.sort((left, right) => left.scheduleMonth.localeCompare(right.scheduleMonth));
          this.orderMonth = 1;
        }
        else if (this.orderMonth == 1){
          this.scheduleList.sort((right, left) => left.scheduleMonth.localeCompare(right.scheduleMonth));
          this.orderMonth = 0;
        }
      }

      searchScheduleFx(){
    
        if(!this.searchSchedule){
            this.scheduleId=null;
            this.programList=null;
            this.programId=null;
            this.service.getSchedules().subscribe((scheduleList:ScheduleModel[]) => this.scheduleList = scheduleList);
    
        }
        else{
          
        for(let i=this.scheduleList.length-1;i>=0 ;i--){
          if(this.searchSchedule != this.scheduleList[i].scheduleMonth){
            this.scheduleList.splice(i,1);
          }
        }
      }
    }

    sortProgramName() {
        if (this.orderProgramName != 1) {
          this.programList.sort((left, right) => left.programName.localeCompare(right.programName));
          this.orderProgramName = 1;
        }
        else if (this.orderProgramName == 1){
          this.programList.sort((right, left) => left.programName.localeCompare(right.programName));
          this.orderProgramName = 0;
        }
      }

      searchProgramFx(){
    
        if(!this.searchProgram){
            this.programId=null;
            this.service.getPrograms(this.scheduleId).subscribe((programList:ProgramModel[]) => this.programList = programList);
           
        }
        else{
          
        for(let i=this.programList.length-1;i>=0 ;i--){
          if(this.searchProgram != this.programList[i].programName){
            this.programList.splice(i,1);
          }
        }
      }
    }
    

}