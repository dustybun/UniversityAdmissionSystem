import {Component, OnInit} from '@angular/core';
import { ScheduleModel } from '../_model/app.schedulemodel';
import {UasService} from '../_service/app.uasservice';
import { ProgramModel } from '../_model/app.programmodel';
import {ApplicantModel} from '../_model/app.applicantmodel';
import {Router} from "@angular/router"

@Component({
    selector: 'addapplicant',
    templateUrl: '../_html/app.addapplicant.html'
})
export class AddApplicantComponent implements OnInit{
    // p: number = 1;

    model:any={};
    scheduleList:ScheduleModel[]=[];
    programList:ProgramModel[]=[];
    applicant:any={applicantName:""};
    scheduleId:any;
    programId:any;
    dateAndTime:string;
    errorMessage:any;
    orderMonth:any;
    orderProgramName:any;
    searchSchedule:any;
    searchProgram:any;
    // newApplicant:any={applicantName:"", contactNo:"", applicantEmail:"", age:"", gender:""};


    constructor(private service:UasService, private router:Router){    
 
    }
    
    ngOnInit(){
        // if(!(sessionStorage.getItem('userRole')==="ROLE_Customer")){
        //     this.router.navigate(['forbidden'])
        // }
        this.scheduleId=null;
        this.programId=null;
        this.programList=null;
        this.service.getSchedules().subscribe((scheduleList:ScheduleModel[]) => this.scheduleList = scheduleList);
    }

    selectSchedule(schedule:ScheduleModel){
        if(this.scheduleId == null)
        {
            this.scheduleId=schedule.scheduleId;
            this.scheduleList=[];
            this.scheduleList.push(schedule);
            this.service.getPrograms(schedule.scheduleId).subscribe((programList:ProgramModel[]) => this.programList = programList);
        }   
    }

    changeSchedule(){
        this.ngOnInit();
    }

    selectProgram(program:ProgramModel){
        this.programId=program.programId;
        this.programList=[];
        this.programList.push(program);
    }

    changeProgram(){
        this.programId = null;
        this.service.getPrograms(this.scheduleId).subscribe((programList:ProgramModel[]) => this.programList = programList);
    }

    confirmApplicant(){

      this.applicant.applicantEmail = this.model.applicantEmail;
        this.applicant.applicantName = this.model.applicantName;
        //this.applicant.applicantPassword = this.model.userPassword;
        this.applicant.contactNo = this.model.contactNo;
        this.applicant.applicantAge = this.model.applicantAge;
        this.applicant.applicantGender = this.model.applicantGender;
       
        this.applicant.scheduleId = this.scheduleId;
        this.applicant.programId = this.programId;
       // this.applicant.dateAndTime = this.dateAndTime;
        this.applicant.applicantId = sessionStorage.getItem('applicantId');
        this.service.addApplicant(this.applicant).subscribe(
            (data:any)=>{alert("Application applied successfully");
            this.router.navigate(['/userhome'])},
            error => this.errorMessage= error.error
            );
    }

    
  sortName() {
    if (this.orderMonth != 1) {
      this.scheduleList.sort((left, right) => left.scheduleMonth.localeCompare(right.scheduleMonth));
      this.orderMonth = 1;
    }
    else if (this.orderMonth == 1){
      this.scheduleList.sort((right, left) => left.scheduleMonth.localeCompare(right.scheduleMonth));
      this.orderMonth = 0;
    }
  }

  searchScheduleFx(){
   
    if(!this.searchSchedule){
        this.scheduleId=null;
        this.programId=null;
        this.programList=null;
        this.service.getSchedules().subscribe((scheduleList:ScheduleModel[]) => this.scheduleList = scheduleList);
  
      }
      else{
    for(let i=this.scheduleList.length-1;i>=0 ;i--){
      if(this.searchSchedule != this.scheduleList[i].scheduleMonth){
        this.scheduleList.splice(i,1);
      }
    }
  }}

  sortProgramName() {
    if (this.orderProgramName != 1) {
      this.programList.sort((left, right) => left.programName.localeCompare(right.programName));
      this.orderProgramName = 1;
    }
    else if (this.orderProgramName == 1){
      this.programList.sort((right, left) => left.programName.localeCompare(right.programName));
      this.orderProgramName = 0;
    }
  }

  searchProgramFx(){
   
    if(!this.searchProgram){
        this.programId=null;
        this.programList=null;
        this.service.getPrograms(this.scheduleId).subscribe((programList:ProgramModel[]) => this.programList = programList);
   
      }
      else{
    for(let i=this.programList.length-1;i>=0 ;i--){
      if(this.searchProgram != this.programList[i].programName){
        this.programList.splice(i,1);
      }
    }
  }}

}