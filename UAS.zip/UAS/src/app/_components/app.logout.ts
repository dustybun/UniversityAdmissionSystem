import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UasService } from '../_service/app.uasservice';

@Component({
  selector: 'logout',
  templateUrl: '../_html/app.logout.html',
})
export class LogoutComponent implements OnInit {

  constructor(
    private service:UasService,
    private router: Router) {

  }

  ngOnInit() {
    this.service.logOut();
    this.router.navigate(['login']);
  }

}