import {Component, OnInit} from '@angular/core';
import { UasService } from '../_service/app.uasservice';
import { ApplicantModel } from '../_model/app.applicantmodel';
import { saveAs } from 'file-saver';
import { Router } from '@angular/router';

@Component({
    selector: 'viewapplicant',
    templateUrl: '../_html/app.viewapplicant.html'
})

export class ViewApplicant implements OnInit{

    applicantList:ApplicantModel[]=[];
    orderMonth:any;
    orderDate:any;
    searchSchedule:any='';

    constructor(private service:UasService, private router:Router){

    }

    
    ngOnInit(){
        // if(!(sessionStorage.getItem('userRole') === "ROLE_Customer")){
        //   this.router.navigate(['/home']);
        // }
        this.getList();
    }

    getList(){   
        this.service.getUserApplicants(sessionStorage.getItem('applicantId')).subscribe(

            (applicantList:ApplicantModel[]) => {
            (this.applicantList = applicantList)
              //console.log(this.applicantList[0].schedule.scheduleMonth)
          }
            ,
            error => alert(error.error)
            );
    }

    downloadExcel(){
      this.service.download(sessionStorage.getItem('userId')).subscribe(
        response => {
          var blob = new Blob([response], {type: 'application/xlsx'});
          
          var filename = 'applicants.xlsx';
          saveAs(blob,filename);        
        } ,
      error=>{
        alert("Some error");
      }
      );
    }

    
   

  sortMonth() {
    if (this.orderMonth != 1) {
      this.applicantList.sort((left, right) => left.schedule.scheduleMonth.localeCompare(right.schedule.scheduleMonth));
      this.orderMonth = 1;
    }
    else if (this.orderMonth == 1){
      this.applicantList.sort((right, left) => left.schedule.scheduleMonth.localeCompare(right.schedule.scheduleMonth));
      this.orderMonth = 0;
    }
  }

  sortDate() {
    if (this.orderDate != 1) {
      this.applicantList.sort((left, right) => left.dateTime.localeCompare(right.dateTime));
      this.orderDate = 1;
    }
    else if (this.orderDate == 1){
      this.applicantList.sort((right, left) => left.dateTime.localeCompare(right.dateTime));
      this.orderDate = 0;
    }
  }

  searchScheduleFx(){
    
    if(!this.searchSchedule){
      this.getList();
    }
    else{
      
    for(let i=this.applicantList.length-1;i>=0 ;i--){
      if(this.searchSchedule != this.applicantList[i].schedule.scheduleMonth){
        this.applicantList.splice(i,1);
      }
    }
  }
}


}