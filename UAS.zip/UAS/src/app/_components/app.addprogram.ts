import { Component, OnInit, ElementRef, ViewChild } from "@angular/core";
import { UasService } from "../_service/app.uasservice";
import { ScheduleModel } from "../_model/app.schedulemodel";
import { ProgramModel } from "../_model/app.programmodel";
import {FileUploader} from 'ng2-file-upload'
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Router } from "@angular/router";
import { text } from "@angular/core/src/render3/instructions";

@Component({
    selector:'addprogram',
    templateUrl:'../_html/app.addprogram.html'


})

export class AddProgramComponent implements OnInit
{
    scheduleList:ScheduleModel[]=[];
    model:ProgramModel={programId:null,programName:null};
    errorMessage: any;
    myFiles:string [] = [];
    sMsg:string = '';
    schedule:any={};
    

    constructor(private service:UasService, private myhttp:HttpClient, private router:Router){
        
    }
    ngOnInit(): void {
      // if(!(sessionStorage.getItem('userRole') === "ROLE_Admin")){
      //   this.router.navigate(['forbidden']);
    //}
        this.service.getSchedules().subscribe((scheduleListS:ScheduleModel[]) => this.scheduleList = scheduleListS);
        console.log(this.scheduleList);
    }
    addProgram(scheduleId:any):any
    {
         //console.log(this.model.programName)
        //alert("scheduleId"+scheduleId)
       // alert(scheduleId);
       if(scheduleId!=undefined && scheduleId!=null && this.model.programName!=null)
        this.service.addProgram(scheduleId,this.model).subscribe((data:any)=>{alert("Program added successfully");
        location.reload();
        
    },error => this.errorMessage= error.error);
       
    }
    


    getFileDetails (e) {
      //console.log (e.target.files);

      for (var i = 0; i < e.target.files.length; i++) { 
        this.myFiles.push(e.target.files[i]);
      }
    }

  uploadFiles(scheduleId: any) {

  if ((this.schedule.scheduleId != undefined) && (this.myFiles.length > 0)) {
      const frmData = new FormData();

      for (var i = 0; i < this.myFiles.length; i++) {
        frmData.append("file", this.myFiles[i]);
      }

      this.myhttp.post('http://'+ window.location.hostname+':9123/uploadprogram?scheduleId=' + this.schedule.scheduleId, frmData,{responseType:'text'}).subscribe(
        data => {
          // SHOW A MESSAGE RECEIVED FROM THE WEB API.
          this.sMsg = data as string;
          console.log(this.sMsg);
          alert("Added successfully!")
          location.reload();
        }
        ,
        (err: HttpErrorResponse) => {
          console.log(err.message);    // Show error, if any.
        }
      );
    }

    else {
      if(this.schedule.scheduleId == undefined){
        this.errorMessage = "select schedule";
      }
      else{
      this.errorMessage = "choose a file first to upload";
    }
  }
  
  }

   
}