export class ProgramModel{
    programId:any;
    programName:string;
}