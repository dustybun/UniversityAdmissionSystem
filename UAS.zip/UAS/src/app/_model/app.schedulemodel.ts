export class ScheduleModel{
    scheduleId:any;
    scheduleMonth:string;
    }