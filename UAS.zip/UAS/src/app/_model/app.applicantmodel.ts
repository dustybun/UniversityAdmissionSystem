import { ScheduleModel } from "./app.schedulemodel";
import { ProgramModel } from "./app.programmodel";
import { UserModel } from "./app.usermodel";

export class ApplicantModel{
    applicantId:any;
    schedule:ScheduleModel;
    program:ProgramModel;
    user:UserModel;
    applicantAppliedStatus:any;
    dateTime:any;
    applicantName:string;
	contactNo :any;
    applicantEmail: any;
    applicantAge : any;
	applicantGender : any;
	applicantAddress :any;
	applicantCity : string;
	applicantSchoolName : any;
	applicantHscPercentage : any;
	applicantSscPercentage : any;
	applicantJEEMarks:any;



		//this.applicantAcceptedStatus = applicantAcceptedStatus;
		//this.applicantConfirmedStatus = applicantConfirmedStatus;
		
}