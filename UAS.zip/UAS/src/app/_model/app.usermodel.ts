export class UserModel{
    userId:any;
    userPassword:any;
    userName:any;
    userRole:any;
    userEmail:any;

}